import type { Express } from "express";
import { createServer, type Server } from "http";
import { productsData } from "../client/src/lib/products";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route to get all products
  app.get("/api/products", async (req, res) => {
    try {
      res.json(productsData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // API route to get a specific product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const product = productsData.find(p => p.id === id);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
