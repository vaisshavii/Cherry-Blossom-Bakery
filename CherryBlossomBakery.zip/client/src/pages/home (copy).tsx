import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import FloatingBackground from "@/components/floating-background";
import ProductModal from "@/components/product-modal";
import WhatsAppPopup from "@/components/whatsapp-popup";
import { productsData, ProductData, createWhatsAppLink } from "@/lib/products";
import headerBgImage from "@assets/35589cbc512334cefd68c14c04ad6df8_1752239459036.jpg";
import bodyBgImage from "@assets/26ef6ffab627437ef8d86bc83d9466fd_1752239686455.jpg";

export default function Home() {
  const [selectedProduct, setSelectedProduct] = useState<ProductData | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showNav, setShowNav] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  const openProductModal = (product: ProductData) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedProduct(null);
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const controlNavbar = () => {
      if (window.scrollY > lastScrollY && window.scrollY > 100) {
        setShowNav(false);
      } else {
        setShowNav(true);
      }
      setLastScrollY(window.scrollY);
    };

    window.addEventListener('scroll', controlNavbar);
    return () => window.removeEventListener('scroll', controlNavbar);
  }, [lastScrollY]);

  return (
    <div className="scroll-smooth">
      <div 
        className="floral-background"
        style={{
          backgroundImage: `url(${bodyBgImage})`
        }}
      />
      <FloatingBackground />
      
      {/* Header */}
      <header 
        className="relative py-16 px-5 text-center shadow-sm overflow-hidden"
        style={{
          backgroundImage: `url(${headerBgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          minHeight: '500px'
        }}
      >
        {/* Overlay for better text readability */}
        <div className="absolute inset-0 z-0 bg-white/40"></div>
        
        {/* Content */}
        <div className="relative z-10 max-w-4xl mx-auto">
          <h1 className="font-serif text-5xl md:text-7xl text-primary font-light mb-4 tracking-tight">
            Cherry Blossom
          </h1>
          <h2 className="font-serif text-3xl md:text-4xl text-cherry-dark font-normal mb-6 tracking-wide">
            Home Bakery
          </h2>
          <p className="text-lg text-secondary font-normal">
            Pure Vegetarian • Made with Love • Rewa, MP 🎀
          </p>
        </div>
      </header>

      {/* Navigation */}
      <nav className={`bg-white/95 backdrop-blur-md py-4 text-center sticky top-0 z-50 shadow-sm border-b border-gray-100 transition-transform duration-300 ${showNav ? 'translate-y-0' : '-translate-y-full'}`}>
        <div className="max-w-4xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => scrollToSection('menu')}
            className="text-secondary mx-3 md:mx-6 font-medium hover:text-cherry-dark hover:-translate-y-0.5 transition-all duration-300"
          >
            Menu
          </Button>
          <Button
            variant="ghost"
            onClick={() => scrollToSection('about')}
            className="text-secondary mx-3 md:mx-6 font-medium hover:text-cherry-dark hover:-translate-y-0.5 transition-all duration-300"
          >
            About
          </Button>
          <Button
            variant="ghost"
            onClick={() => scrollToSection('delivery')}
            className="text-secondary mx-3 md:mx-6 font-medium hover:text-cherry-dark hover:-translate-y-0.5 transition-all duration-300"
          >
            Delivery
          </Button>
          <Button
            variant="ghost"
            onClick={() => scrollToSection('contact')}
            className="text-secondary mx-3 md:mx-6 font-medium hover:text-cherry-dark hover:-translate-y-0.5 transition-all duration-300"
          >
            Contact
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="gradient-cherry-rose text-white py-20 px-5 text-center relative overflow-hidden">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-serif text-4xl md:text-5xl mb-6 font-light tracking-tight">
            Fresh Baked with Love
          </h2>
          <p className="text-lg md:text-xl mb-10 font-light opacity-95 max-w-2xl mx-auto leading-relaxed">
            Indulge in our artisan treats, crafted with premium ingredients and traditional techniques for exceptional taste
          </p>
          <Button
            onClick={() => scrollToSection('menu')}
            className="bg-white text-cherry-dark py-3 px-8 rounded-full font-medium text-lg shadow-lg btn-hover-strong hover:bg-white border-0"
          >
            View Our Menu
          </Button>
        </div>
      </section>

      {/* Menu Section */}
      <div className="py-20 px-5 max-w-6xl mx-auto" id="menu">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-primary mb-4 font-light">
            Our Menu
          </h2>
          <p className="text-secondary text-lg">Handcrafted treats made with premium ingredients</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
          {productsData.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg product-card cursor-pointer border border-gray-100"
              onClick={() => openProductModal(product)}
            >
              <div className="w-full h-40 product-image-placeholder relative">
                <div className="absolute inset-0 flex items-center justify-center text-secondary font-medium text-xs text-center p-2">
                  {product.image}
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold text-primary mb-2 line-clamp-2">{product.name}</h3>
                <div className="text-lg font-medium text-cherry mb-2">{product.price}</div>
                <div className="inline-block bg-green-100 text-green-700 py-1 px-2 rounded-full text-xs font-medium mb-3">
                  Pure Veg
                </div>
                <p className="text-secondary text-xs mb-3 leading-relaxed line-clamp-2">{product.description}</p>
                <Button className="gradient-cherry-rose text-white py-2 px-4 rounded-lg font-medium btn-hover w-full text-sm">
                  View Details
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* About Section */}
      <div className="bg-white rounded-2xl p-12 shadow-sm my-16 mx-5 max-w-4xl lg:mx-auto border border-gray-100" id="about">
        <div className="text-center mb-8">
          <h2 className="font-serif text-4xl md:text-5xl text-primary mb-4 font-light">
            About Us
          </h2>
          <div className="w-16 h-px bg-cherry mx-auto"></div>
        </div>
        <div className="text-lg text-secondary space-y-6 leading-relaxed">
          <p>
            Welcome to Cherry Blossom Home Bakery. I'm <span className="font-semibold text-cherry-dark">Vaishnavi</span>, 
            and I'm passionate about creating exceptional baked goods that bring joy to your everyday moments and special occasions.
          </p>
          <p>
            Our bakery specializes in <span className="font-semibold text-cherry-dark">100% pure vegetarian</span> artisan treats, 
            made fresh to order using premium ingredients and traditional baking techniques. Every item is crafted with 
            meticulous attention to detail and genuine care.
          </p>
          <p>
            From our signature muffins to elegant bento cakes, we believe exceptional taste comes from using only the finest 
            ingredients and time-honored methods. All products are made in small batches to ensure peak freshness and quality.
          </p>
        </div>
        <div className="text-center mt-8">
          <Button 
            onClick={() => window.open(createWhatsAppLink(), '_blank')}
            className="gradient-cherry-rose text-white py-3 px-8 rounded-lg font-medium text-lg shadow-lg btn-hover-strong"
          >
            Connect with Vaishnavi
          </Button>
        </div>
      </div>

      {/* Delivery Section */}
      <div className="bg-white rounded-2xl p-12 shadow-sm my-16 mx-5 max-w-4xl lg:mx-auto border border-gray-100" id="delivery">
        <div className="text-center mb-8">
          <h2 className="font-serif text-4xl md:text-5xl text-primary mb-4 font-light">
            Delivery Information
          </h2>
          <div className="w-16 h-px bg-cherry mx-auto"></div>
        </div>
        <div className="grid md:grid-cols-2 gap-8 text-secondary">
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Delivery Areas</h3>
            <p>
              We deliver fresh baked goods throughout <span className="font-semibold">Rewa, Madhya Pradesh</span> and surrounding areas.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Delivery Charges</h3>
            <p className="mb-2">₹50 delivery fee for orders below ₹600</p>
            <p className="font-semibold text-green-600">FREE delivery for orders ₹600 and above</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Ordering Process</h3>
            <p>Place orders via WhatsApp at least 24 hours in advance for best availability.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Packaging</h3>
            <p>All items are carefully packaged to ensure freshness and safe delivery.</p>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="bg-white rounded-2xl p-12 shadow-sm my-16 mx-5 max-w-4xl lg:mx-auto border border-gray-100" id="contact">
        <div className="text-center">
          <h2 className="font-serif text-4xl md:text-5xl text-primary mb-6 font-light">
            Get in Touch
          </h2>
          <div className="w-16 h-px bg-cherry mx-auto mb-8"></div>
          <p className="text-xl text-secondary mb-8 max-w-md mx-auto">
            Ready to order fresh baked treats? Contact us on WhatsApp for easy ordering.
          </p>
          <Button
            onClick={() => window.open(createWhatsAppLink(), '_blank')}
            className="gradient-cherry-rose text-white py-3 px-8 rounded-lg font-medium text-lg shadow-lg btn-hover-strong mb-8"
          >
            Order on WhatsApp
          </Button>
          <div className="text-lg text-secondary space-y-3">
            <p><span className="font-semibold">+91 9589280351</span></p>
            <p>Rewa, Madhya Pradesh</p>
            <p>Available: 9 AM - 8 PM (Daily)</p>
          </div>
        </div>
      </div>

      {/* Policies Section */}
      <div className="bg-white rounded-2xl p-12 shadow-sm my-16 mx-5 max-w-4xl lg:mx-auto border border-gray-100">
        <div className="text-center mb-8">
          <h2 className="font-serif text-4xl md:text-5xl text-primary mb-4 font-light">
            Our Policies
          </h2>
          <div className="w-16 h-px bg-cherry mx-auto"></div>
        </div>
        <div className="grid md:grid-cols-2 gap-8 text-secondary">
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Ingredients</h3>
            <p className="mb-2">We use only premium, fresh ingredients in all our baked goods</p>
            <p className="mb-2">100% pure vegetarian - no eggs, gelatin, or animal products</p>
            <p>All products are made in a hygienic, clean environment</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Ordering</h3>
            <p className="mb-2">Large orders: Place 2 days in advance</p>
            <p className="mb-2">Small orders: Place 1 day in advance</p>
            <p className="mb-2">Payment on delivery or advance as per convenience</p>
            <p>Custom orders and special requests are welcome</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Delivery</h3>
            <p className="mb-2">Free delivery on orders ₹600 and above</p>
            <p className="mb-2">₹50 delivery charge for orders below ₹600</p>
            <p>Delivery available throughout Rewa, MP</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-cherry-dark mb-4">Quality</h3>
            <p className="mb-2">All products are baked fresh on order date</p>
            <p className="mb-2">No preservatives or artificial colors used</p>
            <p>100% satisfaction guaranteed</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-800 to-gray-900 text-white text-center py-16 px-5 mt-24">
        <div className="max-w-4xl mx-auto">
          <h3 className="font-serif text-2xl mb-2 font-light">Cherry Blossom Home Bakery</h3>
          <p className="text-gray-300 mb-6">Spreading sweetness, one treat at a time</p>
          <div className="w-16 h-px bg-gray-600 mx-auto mb-6"></div>
          <p className="text-sm text-gray-400">© 2024 Cherry Blossom Home Bakery. Made with love in Rewa, MP.</p>
        </div>
      </footer>

      {/* Product Modal */}
      <ProductModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={closeModal}
      />

      {/* WhatsApp Popup */}
      <WhatsAppPopup />
    </div>
  );
}
