export default function FloatingBackground() {
  return (
    <div className="cherry-blossom-bg" />
  );
}
