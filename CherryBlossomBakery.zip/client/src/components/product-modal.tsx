import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ProductData, ProductVariant, createWhatsAppLink } from "@/lib/products";
import { X } from "lucide-react";

interface ProductModalProps {
  product: ProductData | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ProductModal({ product, isOpen, onClose }: ProductModalProps) {
  if (!product) return null;

  const handleWhatsAppOrder = (variant?: ProductVariant) => {
    const link = createWhatsAppLink(product, variant);
    window.open(link, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0 rounded-2xl overflow-hidden modal-animation">
        <div className="gradient-cherry-rose text-white py-8 px-8 text-center relative">
          <DialogHeader>
            <DialogTitle className="m-0 text-3xl font-serif text-white font-light">
              {product.name}
            </DialogTitle>
            <DialogDescription className="text-white/90 text-lg font-medium mt-2">
              {product.price}
            </DialogDescription>
          </DialogHeader>
          <Button
            variant="ghost" 
            size="icon"
            className="absolute top-4 right-5 text-3xl text-white hover:bg-white/20 hover:scale-110 transition-all duration-300"
            onClick={onClose}
          >
            <X size={24} />
          </Button>
        </div>
        
        <div className="p-10">
          <div className="text-center my-5 product-image-placeholder py-8 rounded-2xl">
            <div className="text-2xl font-medium text-gray-600">{product.image}</div>
          </div>
          
          {/* Image Gallery Placeholder */}
          <div className="grid grid-cols-3 gap-2 my-6">
            <div className="aspect-square product-image-placeholder rounded-lg">
              <div className="text-xs text-gray-500 h-full flex items-center justify-center">Image 1</div>
            </div>
            <div className="aspect-square product-image-placeholder rounded-lg">
              <div className="text-xs text-gray-500 h-full flex items-center justify-center">Image 2</div>
            </div>
            <div className="aspect-square product-image-placeholder rounded-lg">
              <div className="text-xs text-gray-500 h-full flex items-center justify-center">Image 3</div>
            </div>
          </div>
          
          <div className="my-6">
            <h3 className="text-cherry-dark mb-4 text-xl font-semibold">Product Details</h3>
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <h4 className="text-blue-700 font-semibold mb-2">Pack Information</h4>
              <p className="text-blue-600 text-sm">
                {product.name.includes('Muffin') && 'Pack of 6 pieces'}
                {product.name.includes('Cupcake') && 'Pack of 4 pieces'}
                {product.name.includes('Cookie') && 'Pack of 6 pieces'}
                {product.name.includes('Bomboloni') && 'Minimum order 2 pieces'}
                {product.name.includes('Bento') && 'Individual cake (serves 1-2 people)'}
                {product.name.includes('Dry Cake') && 'Individual cake'}
              </p>
            </div>
            <p className="my-3 text-secondary text-lg leading-relaxed">{product.detailDescription}</p>
          </div>
          
          {/* Ingredients Section */}
          <div className="my-6">
            <h3 className="text-cherry-dark mb-4 text-xl font-semibold">Ingredients</h3>
            <p className="text-secondary text-base leading-relaxed">
              Premium flour, fresh butter, organic sugar, pure vanilla extract, fresh eggs (for non-vegan items), 
              and other high-quality ingredients. All products are 100% vegetarian and made without preservatives.
            </p>
          </div>
          
          <div className="bg-gray-50 p-6 rounded-2xl my-6">
            <h3 className="text-cherry-dark mb-4 text-xl font-semibold">Available Varieties & Pricing</h3>
            {product.variants.map((variant, index) => (
              <div key={index} className="flex justify-between items-center py-3 border-b border-gray-200 last:border-b-0">
                <span className="font-medium text-primary">{variant.name}</span>
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-cherry text-lg">{variant.price}</span>
                  <Button
                    size="sm"
                    onClick={() => handleWhatsAppOrder(variant)}
                    className="gradient-cherry-rose text-white hover:opacity-90 btn-hover rounded-lg"
                  >
                    Order
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-green-50 p-4 rounded-lg mb-6">
            <h4 className="text-green-700 font-semibold mb-2">Ordering & Delivery Information</h4>
            <p className="text-green-600 text-sm mb-2">
              Large orders: Place 2 days in advance • Small orders: Place 1 day in advance
            </p>
            <p className="text-green-600 text-sm">
              Free delivery on orders ₹600 and above • ₹50 delivery charge for orders below ₹600
            </p>
          </div>
          
          <div className="text-center">
            <Button
              onClick={() => handleWhatsAppOrder()}
              className="gradient-cherry-rose text-white py-3 px-8 rounded-lg font-medium text-lg btn-hover-strong"
            >
              Order via WhatsApp
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
