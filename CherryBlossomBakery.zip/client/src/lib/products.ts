export interface ProductVariant {
  name: string;
  price: string;
}

export interface ProductData {
  id: string;
  name: string;
  image: string;
  price: string;
  description: string;
  category: string;
  variants: ProductVariant[];
  detailDescription: string;
}

export const productsData: ProductData[] = [
  {
    id: "muffin-chocochip",
    name: "Chocolate Chip Muffins",
    image: "Chocolate Chip Muffins",
    price: "₹130",
    description: "Pack of 6 - Freshly baked muffins with premium chocolate chips",
    category: "Muffins",
    detailDescription: "Our signature chocolate chip muffins are crafted daily with the finest ingredients and premium chocolate chips. Each muffin is perfectly baked to achieve a tender crumb and delightful taste. Pack of 6 pieces.",
    variants: [
      { name: "Pack of 6", price: "₹130" }
    ]
  },
  {
    id: "muffin-banana-chocochip",
    name: "Banana Chocolate Chip Muffins",
    image: "Banana Chocolate Chip Muffins",
    price: "₹150",
    description: "Pack of 6 - Moist banana muffins with chocolate chips",
    category: "Muffins",
    detailDescription: "Delicious banana muffins combined with rich chocolate chips for the perfect flavor combination. Made with fresh bananas and premium ingredients. Pack of 6 pieces.",
    variants: [
      { name: "Pack of 6", price: "₹150" }
    ]
  },
  {
    id: "muffin-tutti-frutti",
    name: "Tutti Frutti Vanilla Muffins",
    image: "Tutti Frutti Vanilla Muffins",
    price: "₹130",
    description: "Pack of 6 - Vanilla muffins with colorful tutti frutti",
    category: "Muffins",
    detailDescription: "Light and fluffy vanilla muffins studded with colorful tutti frutti pieces. A delightful treat that brings joy with every bite. Pack of 6 pieces.",
    variants: [
      { name: "Pack of 6", price: "₹130" }
    ]
  },
  {
    id: "muffin-nuts",
    name: "Nuts Muffins",
    image: "Nuts Muffins",
    price: "₹150",
    description: "Pack of 6 - Rich muffins with mixed nuts",
    category: "Muffins",
    detailDescription: "Wholesome muffins packed with a variety of premium nuts for extra crunch and nutrition. Perfect for a healthy indulgence. Pack of 6 pieces.",
    variants: [
      { name: "Pack of 6", price: "₹150" }
    ]
  },
  {
    id: "cupcake-vanilla",
    name: "Vanilla Cupcakes",
    image: "Vanilla Cupcakes",
    price: "₹120",
    description: "Pack of 4 - Classic vanilla cupcakes with smooth frosting",
    category: "Cupcakes",
    detailDescription: "Classic vanilla cupcakes with rich, moist cake base and smooth vanilla frosting. Perfect for any celebration or sweet craving. Pack of 4 pieces.",
    variants: [
      { name: "Pack of 4", price: "₹120" }
    ]
  },
  {
    id: "cupcake-chocochip",
    name: "Chocolate Chip Cupcakes",
    image: "Chocolate Chip Cupcakes",
    price: "₹120",
    description: "Pack of 4 - Vanilla cupcakes with chocolate chips",
    category: "Cupcakes",
    detailDescription: "Delicious vanilla cupcakes studded with chocolate chips and topped with creamy frosting. A perfect combination of vanilla and chocolate. Pack of 4 pieces.",
    variants: [
      { name: "Pack of 4", price: "₹120" }
    ]
  },
  {
    id: "cupcake-chocofilled",
    name: "Chocolate Filled Cupcakes",
    image: "Chocolate Filled Cupcakes",
    price: "₹150",
    description: "Pack of 4 - Cupcakes with rich chocolate filling",
    category: "Cupcakes",
    detailDescription: "Premium cupcakes with a surprise chocolate filling inside and elegant frosting on top. A decadent treat for chocolate lovers. Pack of 4 pieces.",
    variants: [
      { name: "Pack of 4", price: "₹150" }
    ]
  },
  {
    id: "cookies-chocochip",
    name: "Chocolate Chip Cookies",
    image: "Chocolate Chip Cookies",
    price: "₹120",
    description: "Pack of 6 - Crispy cookies with chocolate chips",
    category: "Cookies",
    detailDescription: "Classic chocolate chip cookies baked to perfection with a crispy exterior and soft center. Made with premium chocolate chips. Pack of 6 pieces.",
    variants: [
      { name: "Pack of 6", price: "₹120" }
    ]
  },
  {
    id: "cookies-coconut",
    name: "Coconut Cookies",
    image: "Coconut Cookies",
    price: "₹120",
    description: "Pack of 6 - Crispy cookies with coconut flakes",
    category: "Cookies",
    detailDescription: "Delicious coconut cookies with real coconut flakes for an authentic tropical flavor. Crispy and perfectly sweet. Pack of 6 pieces.",
    variants: [
      { name: "Pack of 6", price: "₹120" }
    ]
  },
  {
    id: "cookies-nuts",
    name: "Nuts Cookies",
    image: "Nuts Cookies",
    price: "₹130",
    description: "Pack of 6 - Crunchy cookies with mixed nuts",
    category: "Cookies",
    detailDescription: "Premium cookies loaded with a variety of nuts for extra crunch and nutrition. Perfect for a healthy indulgence. Pack of 6 pieces.",
    variants: [
      { name: "Pack of 6", price: "₹130" }
    ]
  },
  {
    id: "bomboloni",
    name: "Bomboloni",
    image: "Bomboloni",
    price: "₹160",
    description: "Minimum order 2 pieces - Italian filled donuts",
    category: "Specialty",
    detailDescription: "Traditional Italian bomboloni made with authentic techniques. These light, airy donuts are filled with premium creams and jams for an authentic Italian experience. Minimum order of 2 pieces.",
    variants: [
      { name: "Minimum 2 pieces", price: "₹160" }
    ]
  },
  {
    id: "bento-vanilla",
    name: "Vanilla Bento Cake",
    image: "Vanilla Bento Cake",
    price: "₹200",
    description: "Individual cake perfect for personal celebrations",
    category: "Bento Cakes",
    detailDescription: "Cute, individual-sized vanilla cake perfect for personal celebrations. Each bento cake is carefully decorated and portioned for 1-2 people.",
    variants: [
      { name: "Individual Cake", price: "₹200" }
    ]
  },
  {
    id: "bento-chocolate",
    name: "Chocolate Bento Cake",
    image: "Chocolate Bento Cake",
    price: "₹210",
    description: "Individual chocolate cake with rich flavor",
    category: "Bento Cakes",
    detailDescription: "Rich chocolate bento cake perfect for chocolate lovers. Individual-sized and beautifully decorated for personal celebrations.",
    variants: [
      { name: "Individual Cake", price: "₹210" }
    ]
  },
  {
    id: "bento-truffle",
    name: "Truffle Bento Cake",
    image: "Truffle Bento Cake",
    price: "₹250",
    description: "Premium truffle cake for special occasions",
    category: "Bento Cakes",
    detailDescription: "Luxurious truffle bento cake made with premium ingredients. Perfect for special celebrations and indulgent moments.",
    variants: [
      { name: "Individual Cake", price: "₹250" }
    ]
  },
  {
    id: "drycake-vanilla",
    name: "Vanilla Dry Cake",
    image: "Vanilla Dry Cake",
    price: "₹170",
    description: "Traditional vanilla cake perfect for gifting",
    category: "Dry Cakes",
    detailDescription: "Traditional vanilla dry cake that stays fresh longer without refrigeration. Perfect for gifting, traveling, or enjoying with tea and coffee.",
    variants: [
      { name: "Individual Cake", price: "₹170" }
    ]
  },
  {
    id: "drycake-chocolate",
    name: "Chocolate Dry Cake",
    image: "Chocolate Dry Cake",
    price: "₹170",
    description: "Rich chocolate cake for special occasions",
    category: "Dry Cakes",
    detailDescription: "Rich chocolate dry cake with deep cocoa flavor. Stays fresh longer without refrigeration, perfect for gifting and special occasions.",
    variants: [
      { name: "Individual Cake", price: "₹170" }
    ]
  },
  {
    id: "drycake-nuts",
    name: "Nuts Dry Cake",
    image: "Nuts Dry Cake",
    price: "₹180",
    description: "Premium cake with mixed nuts",
    category: "Dry Cakes",
    detailDescription: "Premium dry cake loaded with a variety of nuts for extra flavor and nutrition. Perfect for gifting and special occasions.",
    variants: [
      { name: "Individual Cake", price: "₹180" }
    ]
  }
];

export const createWhatsAppLink = (product?: ProductData, variant?: ProductVariant) => {
  const phoneNumber = "919589280351";
  let message = "Hi! I'd like to place an order from Cherry Blossom Bakery";
  
  if (product) {
    message += `\n\nProduct: ${product.name}`;
    if (variant) {
      message += `\nVariant: ${variant.name}`;
      message += `\nPrice: ${variant.price}`;
    }
    message += `\n\nPlease let me know the availability and delivery details.`;
  }
  
  return `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
};
